<?php
    require_once "view/dashboardView.php";