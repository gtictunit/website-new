<?php
    require_once "view/newAMview.php";