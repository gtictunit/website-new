<?php
    require_once "view/viewAMview.php";