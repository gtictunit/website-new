<?php
    require_once "view/newSOTMview.php";