<?php
    require_once "view/indexView.php";