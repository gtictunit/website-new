<a href="userprofile.php">My Profile</a>
<a href="password.php">Change Paswword</a>
<a href="index.php">Log Out</a>