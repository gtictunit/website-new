<a href="dashboard.php">
    <button type="button" class="noncollapsible">
        Dashboard
    </button>
</a>
<button type="button" class="collapsible">Pastor Desk
</button>
<div class="content">
    <a href="newPD.php" >
        <button type="button" class="submenubut">
            New
        </button>
    </a>
    <a href="viewPD.php">
        <button type="button" class="submenubut">
            View
        </button>
    </a>
</div>
<button type="button" class="collapsible">Sermon of the Month
</button>
<div class="content">
    <a href="newSOTM.php" >
        <button type="button" class="submenubut">
           New
        </button>
    </a>
    <a href="viewSOTM.php" >
        <button type="button" class="submenubut">
            View
        </button>
    </a>
</div>
<button type="button" class="collapsible">Audio Message
</button>
<div class="content">
    <a href="newAM.php" >
        <button type="button" class="submenubut">
           New
        </button>
    </a>
    <a href="viewAM.php">
        <button type="button" class="submenubut">
        View
        </button>
    </a>
</div>
<button type="button" class="collapsible">Administrator
</button>
<div class="content">
    <a href="newAD.php" >
        <button type="button" class="submenubut">
           New
        </button>
    </a>
    <a href="viewAD.php">
        <button type="button" class="submenubut">
        View
        </button>
    </a>
</div>
<!--
<button type="button" class="collapsible">
    <i class="fa-solid fa-calendar-days ispace"></i>Year
</button>
<div class="content">
    <a href="setYear.php">
        <button type="button" class="submenubut">
            <i class="fa-solid fa-calendar-days ispace"></i>Set Current Year
        </button>
    </a>
    <a href="closeYear.php">
        <button type="button" class="submenubut">
        <i class="fa-solid fa-circle-xmark ispace"></i>Close Current Year
        </button>
    </a>
</div>

<button type="button" class="collapsible">
    <i class="fa-solid fa-person-circle-check ispace"></i>Attendance
</button>
<div class="content">
    <a href="newChildren.php" >
        <button type="button" class="submenubut">
            <i class="fas fa-plus ispace"></i>New Class
        </button>
    </a>
    <a href="viewChildren.php">
        <button type="button" class="submenubut">
            <i class="fas fa-eye ispace"></i>View Class
        </button>
    </a>
</div>-->
<!--<ul class="menulist">
    <li>
        <a href="dashboard.php"><i class="fa-solid fa-person-walking-arrow-right"></i>Dashboard</a>
    </li>
    <li>
        <a href="teacher.php"><i class="fa-solid fa-user"></i>Users</a>
    </li>
    <li>
        <a href=#><i class="fa-solid fa-children"></i>Children</a>
    </li>
    <li>
        <a href=#><i class="fa-solid fa-landmark"></i>Class</a>
    </li>
    <li>
        <a href=#><i class="fa-solid fa-calendar-days"></i>Year</a>
    </li>
    <li>
        <a href=#><i class="fa-solid fa-person-circle-check"></i>Attendance</a>
    </li>
</ul>-->