<?php
    require_once "view/viewSOTMview.php";